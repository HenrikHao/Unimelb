
import logging, json
from elasticsearch8 import Elasticsearch
from string import Template

def main():
    # connect to ES
    es = Elasticsearch (
        'https://elasticsearch-master.elastic.svc.cluster.local:9200',
        verify_certs= False,
        basic_auth=('elastic', 'elastic')
    )
    index_name='bushfire1'
    expr ='''{"match_all": {}}'''
    try: 
        res= es.search(
            index=index_name,
            query=json.loads(expr),
            size=5000
            )
        return json.dumps(res['hits']['hits'])
    except Exception as e: 
        error_message = {"error": str(e)}
        return json.dumps(error_message)
    
    

if __name__ == "__main__":
    main()

    

import logging, json
from elasticsearch8 import Elasticsearch

def main():
    # Setup Elasticsearch client
    try:
        client = Elasticsearch(
            'https://elasticsearch-master.elastic.svc.cluster.local:9200',
            verify_certs=False,
            basic_auth=('elastic', 'elastic')
        )
        query = {
            "query": {
                "match_all": {}
            },
            "size": 10000
        }

        index = "mastodontoots"
        response = client.search(index=index, body=query)
        return json.dumps(response['hits']['hits'])
    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        return json.dumps({"error": str(e)})